class ScoutProg{
public:
	void meteam(){
	Serial.begin(115200);
	Serial.print("HKScout Meteam");
	}
};