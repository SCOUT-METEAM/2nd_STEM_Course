#include "Arduino.h"

class ScoutProg{
public:
	void meteam();
};


