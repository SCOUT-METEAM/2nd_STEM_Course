#include "Scout.h"
	void ScoutProg::meteam()
	{
	  Serial.begin(115200);
	  Serial.print("HKScout Meteam");
	}
